package com.niit.ChatPrj;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ChatPrj.DAO.CustomerDAO;
import com.niit.ChatPrj.Model.Customer;

//import junit.framework.Test;
import junit.framework.TestCase;
//import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     *
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }*/

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
    	AnnotationConfigApplicationContext ctx;
    	CustomerDAO cd;
    	
    	ctx = new AnnotationConfigApplicationContext();
    	ctx.scan("com.niit.ChatPrj");
    	ctx.refresh();
    	cd = (CustomerDAO)ctx.getBean("customerDAO");
    	Customer c = new Customer();
    	c.setName("asd");
    	c.setPass("123");
    	c.setEmail("abc");
    	cd.addCustomer(c);
    	ctx.close();
    	assertTrue( true );
    }
}
