package com.niit.ChatPrj.DAO;

import com.niit.ChatPrj.Model.Customer;

public interface CustomerDAO {

	void addCustomer(Customer c);
}
