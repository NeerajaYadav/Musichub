package com.niit.ChatPrj.Controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.niit.ChatPrj.DAO.CustomerDAO;
import com.niit.ChatPrj.Model.Customer;

@Controller
public class HomeController {

	static AnnotationConfigApplicationContext ctx;
	static CustomerDAO cd;
	
	static{
		ctx = new AnnotationConfigApplicationContext();
		ctx.scan("com.niit.ChatPrj");
		ctx.refresh();
		cd = (CustomerDAO)ctx.getBean("customerDAO");
	}
	
	@RequestMapping(value="/home/add/", method=RequestMethod.PUT )
	public ResponseEntity<Void> addUser(@RequestBody Customer c,UriComponentsBuilder ubuild){
		cd.addCustomer(c);
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ubuild.path("/register.html").build().toUri());
		return new ResponseEntity<Void>(headers,HttpStatus.CREATED);
	}
	
	@RequestMapping(value="/check",method=RequestMethod.GET)
	public void doso(){
		System.out.println("Done");
	}
}
