angular.module('JSApp',[]).controller('JSCtrl',function($scope,$http){
	$scope.customer = {
		name:'',
		pass:'',
		email:''
	};
	$scope.addCustomer = function(customer){
		$http.put('/ChatPrj/home/add/'+customer).success(function () {
            alert("Customer successfully added to the Database!")
		});
	};
	$scope.check = function(){
		$http.get('/ChatPrj/check').success(function(){
			alert("Alerted");
		});
	};
});