package com.fbook.service;

public interface IEmailService {
	public void Mail(String mailId,String userName);
}
