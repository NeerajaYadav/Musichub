package codes.Service;

public interface ForumServiceDAO {

}
