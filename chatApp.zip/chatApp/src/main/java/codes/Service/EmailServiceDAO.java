package codes.Service;

public interface EmailServiceDAO {

}
