package codes.Service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import codes.DAO.UserDAO;
import codes.Model.ChatUser;

@Service
public class UserService implements UserServiceDAO{

	@Autowired
	UserDAO ud;
	
	@Override
	public void addUser(ChatUser u) {
		ud.addUser(u);
	}

	@Override
	public void delUser(ChatUser u) {
		ud.delUser(u);
	}

	@Override
	public void updUser(ChatUser u) {
		ud.updUser(u);
	}

	@Override
	public ChatUser getUserById(int uid) {
		return ud.getUserById(uid);
	}

	@Override
	public ChatUser getUserByName(String uname) {
		return ud.getUserByName(uname);
	}

	@Override
	public ArrayList<ChatUser> getAllUsers() {
		return ud.getAllUsers();
	}

}
