package codes.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	@RequestMapping("/")
	public String goHome(){
		return "index";
	}
	
	@RequestMapping("/login")
	public String goLogin(){
		return "login";
	}
	
	@RequestMapping("/logout")
	public String goOut(){
		return "logout";
	}
	
	@RequestMapping("/aindex")
	public String goAdmin(){
		return "aindex";
	}
	
	@RequestMapping("/chat")
	public String goChat(){
		return "chat";
	}
	
	@RequestMapping("/forum")
	public String goForum(){
		return "NewForum";
	}
	
	@RequestMapping("/blog")
	public String goBlog(){
		return "NewBlog";
	}
	
	@RequestMapping("/about")
	public String goAbout(){
		return "about";
	}
	
	@RequestMapping("/contact")
	public String goCot(){
		return "contactus";
	}
}
