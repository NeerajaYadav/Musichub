package codes.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import codes.Model.ChatUser;
import codes.Service.UserServiceDAO;

@Controller
public class UserController {

	@Autowired
	UserServiceDAO usd;
	
	ModelAndView m;
	
	@ModelAttribute("user1")
	public ChatUser getUser(){
		return new ChatUser();
	}
	
	@RequestMapping("/register")
	public String goRegister(){
		return "register";
	}
	
	@RequestMapping(value="/addUser",method=RequestMethod.POST)
	public ModelAndView addU(@Valid @ModelAttribute("user1") ChatUser u, @RequestParam("cpass")String cp, BindingResult br ){
		if(br.hasErrors()||!cp.equals(u.getPass())){
			m = new ModelAndView("register");
			return m;
		}
		usd.addUser(u);
		m = new ModelAndView("index");
		return m;
	}
}
