package codes.Controller;

import java.io.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import codes.Model.ChatUser;
import codes.Service.EmailService;
import codes.Service.UserServiceDAO;

@Controller
public class UserController {

	@Autowired
	UserServiceDAO usd;
	@Autowired
	EmailService es;
	
	ModelAndView m;
	
	@ModelAttribute("user1")
	public ChatUser getUser(){
		return new ChatUser();
	}
	
	@RequestMapping("/register")
	public String goRegister(){
		return "register";
	}
	
	@RequestMapping("/userprof")
	public String goprofile(){
		return "UserProfile";
	}
	
	@RequestMapping(value="/addUser",method=RequestMethod.POST)
	public ModelAndView addU(@Valid @ModelAttribute("user1") ChatUser u, @RequestParam("cpass")String cp,HttpServletRequest req, BindingResult br ){
		if(br.hasErrors()||!cp.equals(u.getPass())){
			m = new ModelAndView("register");
			return m;
		}
		usd.addUser(u);
		if(!u.getProfilePic().isEmpty()){
			try{
				byte[] bytes = u.getProfilePic().getBytes();
				String path = req.getSession().getServletContext().getRealPath("/resources/img/"+u.getUserId()+".jpg");
				File f = new File(path);
				BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(f));
				bos.write(bytes);
				bos.close();
			}
			catch(Exception e){
				
			}
		}
		/*try{
			es.send(u, "Your Sit'n Chat Account Activation", "Welcome to Sit'n Chat! You have registered Successfully. ");
		}
		catch(MessagingException me){
			System.out.println(me);
		}*/
		m = new ModelAndView("home");
		return m;
	}
}
