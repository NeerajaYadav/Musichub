package codes.Model;

public class Forum {

}
