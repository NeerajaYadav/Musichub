package codes.DAO;

import java.util.ArrayList;

import codes.Model.ChatUser;

public interface UserDAO {
	void addUser(ChatUser u);
	void delUser(ChatUser u);
	void updUser(ChatUser u);
	ChatUser getUserById(int uid);
	ChatUser getUserByName(String uname);
	ArrayList<ChatUser> getAllUsers();
}
