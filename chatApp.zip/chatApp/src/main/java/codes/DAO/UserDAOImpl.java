  package codes.DAO;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import codes.Model.ChatUser;

@Repository
@Transactional
public class UserDAOImpl implements UserDAO {

	@Autowired
	SessionFactory sf;
	
	Session s;
	Transaction t;
	ChatUser x;
	ArrayList<ChatUser> l;
	
	@Override
	public void addUser(ChatUser u) {
		s = sf.openSession();
		t = s.beginTransaction();
		u.setEnabled(true);
		u.setRole("ROLE_USER");
		s.save(u);
		t.commit();
	}

	@Override
	public void delUser(ChatUser u) {
		s = sf.openSession();
		t = s.beginTransaction();
		s.delete(u);
		t.commit();
	}

	@Override
	public void updUser(ChatUser u) {
		s = sf.openSession();
		t = s.beginTransaction();
		s.saveOrUpdate(u);
		t.commit();
	}

	@Override
	public ChatUser getUserById(int uid) {
		s = sf.openSession();
		t = s.beginTransaction();
		x = (ChatUser)s.load(ChatUser.class, uid);
		t.commit();
		return x;
	}

	@Override
	public ChatUser getUserByName(String uname) {
		s = sf.openSession();
		t = s.beginTransaction();
		x = null;
		getAllUsers();
		for(ChatUser z: l){
			if(z.getUname().equals(uname)){
				x = z;
			}
		}
		return x;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<ChatUser> getAllUsers() {
		s = sf.openSession();
		t = s.beginTransaction();
		l = (ArrayList<ChatUser>)s.createCriteria(ChatUser.class).list();
		return l;
	}

}
