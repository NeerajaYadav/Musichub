package codes.DAO;

public interface ForumDAO {

}
